package enums;

public enum ChildType {
    BABY,
    KID,
    TEEN,
}
