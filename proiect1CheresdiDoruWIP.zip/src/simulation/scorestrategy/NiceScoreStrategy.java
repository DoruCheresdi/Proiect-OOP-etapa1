package simulation.scorestrategy;

import children.Child;

public interface NiceScoreStrategy {
    void calculateScore(Child child);
}
